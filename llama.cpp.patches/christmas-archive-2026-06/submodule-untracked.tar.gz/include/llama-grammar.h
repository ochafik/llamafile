// Stub header that redirects to llama.cpp/src/llama-grammar.h
#pragma once
#include "llama.cpp/src/llama-grammar.h"
