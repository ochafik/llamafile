#-*-mode:makefile-gmake;indent-tabs-mode:t;tab-width:8;coding:utf-8-*-┐
#── vi: set noet ft=make ts=8 sw=8 fenc=utf-8 :vi ────────────────────┘

PKGS += LLAMA_CPP_IMATRIX

LLAMA_CPP_IMATRIX_SRCS := $(wildcard llama.cpp/tools/imatrix/*.cpp)
LLAMA_CPP_IMATRIX_OBJS = $(LLAMA_CPP_IMATRIX_SRCS:%.cpp=o/$(MODE)/%.o)

o/$(MODE)/llama.cpp/tools/imatrix/imatrix:				\
		$(LLAMA_CPP_IMATRIX_OBJS)				\
		o/$(MODE)/llama.cpp/llama.cpp.a

.PHONY: o/$(MODE)/llama.cpp/tools/imatrix
o/$(MODE)/llama.cpp/tools/imatrix:					\
		o/$(MODE)/llama.cpp/tools/imatrix/imatrix
