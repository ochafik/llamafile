#-*-mode:makefile-gmake;indent-tabs-mode:t;tab-width:8;coding:utf-8-*-┐
#── vi: set noet ft=make ts=8 sw=8 fenc=utf-8 :vi ────────────────────┘

PKGS += LLAMA_CPP_QUANTIZE

LLAMA_CPP_QUANTIZE_SRCS := $(wildcard llama.cpp/tools/quantize/*.cpp)
LLAMA_CPP_QUANTIZE_OBJS = $(LLAMA_CPP_QUANTIZE_SRCS:%.cpp=o/$(MODE)/%.o)

o/$(MODE)/llama.cpp/tools/quantize/quantize:				\
		$(LLAMA_CPP_QUANTIZE_OBJS)				\
		o/$(MODE)/llama.cpp/llama.cpp.a

.PHONY: o/$(MODE)/llama.cpp/tools/quantize
o/$(MODE)/llama.cpp/tools/quantize:					\
		o/$(MODE)/llama.cpp/tools/quantize/quantize
