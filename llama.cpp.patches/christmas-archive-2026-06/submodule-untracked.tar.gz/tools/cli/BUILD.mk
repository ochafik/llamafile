#-*-mode:makefile-gmake;indent-tabs-mode:t;tab-width:8;coding:utf-8-*-┐
#── vi: set noet ft=make ts=8 sw=8 fenc=utf-8 :vi ────────────────────┘
#
# CLI (Command Line Interface) BUILD.mk - NATIVE STRUCTURE VERSION
#
# The cli code lives in llama.cpp/tools/cli/ in the native structure
#

PKGS += LLAMA_CPP_CLI

# Main cli source from upstream llama.cpp (in tools/cli/)
LLAMA_CPP_CLI_SRCS := $(wildcard llama.cpp/tools/cli/*.cpp)
LLAMA_CPP_CLI_OBJS = $(LLAMA_CPP_CLI_SRCS:%.cpp=o/$(MODE)/%.o)

# Include paths for cli
LLAMA_CPP_CLI_INCLUDES = -Illama.cpp/tools/cli

$(LLAMA_CPP_CLI_OBJS): private CCFLAGS += $(LLAMA_CPP_CLI_INCLUDES)

o/$(MODE)/llama.cpp/tools/cli/main:				\
		$(LLAMA_CPP_CLI_OBJS)				\
		o/$(MODE)/llamafile/server/server.a		\
		o/$(MODE)/llama.cpp/llama.cpp.a			\
		o/$(MODE)/third_party/mbedtls/mbedtls.a		\
		o/$(MODE)/llamafile/highlight/highlight.a	\
		o/$(MODE)/third_party/stb/stb.a			\

.PHONY: o/$(MODE)/llama.cpp/tools/cli
o/$(MODE)/llama.cpp/tools/cli:					\
		o/$(MODE)/llama.cpp/tools/cli/main
