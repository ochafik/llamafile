// Stub header that redirects to llama.cpp/server/server.h
#pragma once
#include "llama.cpp/server/server.h"
