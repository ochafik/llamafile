#-*-mode:makefile-gmake;indent-tabs-mode:t;tab-width:8;coding:utf-8-*-┐
#── vi: set noet ft=make ts=8 sw=8 fenc=utf-8 :vi ────────────────────┘
#
# llama.cpp/tools/server BUILD.mk - upstream server components
#
# NOTE: This builds the server code from llama.cpp/tools/server/
# The llamafile server is in llamafile/server/
#

PKGS += LLAMA_CPP_TOOLS_SERVER

LLAMA_CPP_TOOLS_SERVER_SRCS := $(wildcard llama.cpp/tools/server/*.cpp)
LLAMA_CPP_TOOLS_SERVER_OBJS = $(LLAMA_CPP_TOOLS_SERVER_SRCS:%.cpp=o/$(MODE)/%.o)
LLAMA_CPP_TOOLS_SERVER_ASSETS := $(wildcard llama.cpp/tools/server/public/*)

# Include paths for server
LLAMA_CPP_TOOLS_SERVER_INCLUDES = -Illama.cpp/tools/server

$(LLAMA_CPP_TOOLS_SERVER_OBJS): private CCFLAGS += $(LLAMA_CPP_TOOLS_SERVER_INCLUDES)

o/$(MODE)/llama.cpp/tools/server/server.a:			\
		$(LLAMA_CPP_TOOLS_SERVER_OBJS)

$(LLAMA_CPP_TOOLS_SERVER_OBJS): llama.cpp/tools/server/BUILD.mk

.PHONY: o/$(MODE)/llama.cpp/tools/server
o/$(MODE)/llama.cpp/tools/server:				\
		o/$(MODE)/llama.cpp/tools/server/server.a
