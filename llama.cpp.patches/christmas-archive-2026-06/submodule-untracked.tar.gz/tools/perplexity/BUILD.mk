#-*-mode:makefile-gmake;indent-tabs-mode:t;tab-width:8;coding:utf-8-*-┐
#── vi: set noet ft=make ts=8 sw=8 fenc=utf-8 :vi ────────────────────┘

PKGS += LLAMA_CPP_PERPLEXITY

LLAMA_CPP_PERPLEXITY_SRCS := $(wildcard llama.cpp/tools/perplexity/*.cpp)
LLAMA_CPP_PERPLEXITY_OBJS = $(LLAMA_CPP_PERPLEXITY_SRCS:%.cpp=o/$(MODE)/%.o)

.PHONY: o/$(MODE)/llama.cpp/tools/perplexity
o/$(MODE)/llama.cpp/tools/perplexity:					\
		o/$(MODE)/llama.cpp/tools/perplexity/perplexity

o/$(MODE)/llama.cpp/tools/perplexity/perplexity:			\
		$(LLAMA_CPP_PERPLEXITY_OBJS)				\
		o/$(MODE)/llama.cpp/llama.cpp.a
