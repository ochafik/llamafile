#-*-mode:makefile-gmake;indent-tabs-mode:t;tab-width:8;coding:utf-8-*-┐
#── vi: set noet ft=make ts=8 sw=8 fenc=utf-8 :vi ────────────────────┘
#
# MTMD (Multimodal Tools) BUILD.mk - NATIVE STRUCTURE VERSION
#
# The mtmd code lives in llama.cpp/tools/mtmd/ in the native structure
#

PKGS += LLAMA_CPP_MTMD

# Main mtmd sources from upstream llama.cpp (in tools/mtmd/)
LLAMA_CPP_MTMD_SRCS := $(wildcard llama.cpp/tools/mtmd/*.cpp)
LLAMA_CPP_MTMD_OBJS = $(LLAMA_CPP_MTMD_SRCS:%.cpp=o/$(MODE)/%.o)

o/$(MODE)/llama.cpp/tools/mtmd.a: $(LLAMA_CPP_MTMD_OBJS)

# Include paths for mtmd
LLAMA_CPP_MTMD_INCLUDES = -Illama.cpp/tools/mtmd

$(LLAMA_CPP_MTMD_OBJS): private CCFLAGS += $(LLAMA_CPP_MTMD_INCLUDES)

.PHONY: o/$(MODE)/llama.cpp/tools/mtmd
o/$(MODE)/llama.cpp/tools/mtmd:				\
		o/$(MODE)/llama.cpp/tools/mtmd.a
