// ggml_barrier implementation for llamafile
// Extracted from ggml-cpu.c to work around C++ header issues
// Also includes lookup tables that are normally defined in ggml-cpu.c and vec.cpp

#include "llama.cpp/ggml/include/ggml.h"

// precomputed f32 table for f16 (256 KB)
// defined in ggml-cpu.c, initialized in ggml_cpu_init()
float ggml_table_f32_f16[1 << 16];

// precomputed gelu table for f16 (128 KB)
ggml_fp16_t ggml_table_gelu_f16[1 << 16];

// precomputed quick gelu table for f16 (128 KB)
ggml_fp16_t ggml_table_gelu_quick_f16[1 << 16];

#include <stdatomic.h>
#include <pthread.h>

#ifndef GGML_THREADPOOL_N_THREADS_MASK
#define GGML_THREADPOOL_N_THREADS_MASK ((1 << 20) - 1)
#endif

#ifndef ggml_thread_cpu_relax
#if defined(__x86_64__) || defined(__i386__)
#define ggml_thread_cpu_relax() __asm__ __volatile__("pause")
#elif defined(__aarch64__)
#define ggml_thread_cpu_relax() __asm__ __volatile__("yield")
#else
#define ggml_thread_cpu_relax() ((void)0)
#endif
#endif

// Types from ggml-cpu.c
typedef pthread_cond_t     ggml_cond_t;
typedef pthread_mutex_t    ggml_mutex_t;

#ifndef GGML_MAX_N_THREADS
#define GGML_MAX_N_THREADS 512
#endif

// Forward declaration
struct ggml_compute_state;

// Threadpool definition from ggml-cpu.c
struct ggml_threadpool {
    ggml_mutex_t mutex;       // mutex for cond.var
    ggml_cond_t  cond;        // cond.var for waiting for new work

    struct ggml_cgraph * cgraph;
    struct ggml_cplan  * cplan;

    // synchronization primitives
    atomic_int n_graph;       // updated when there is work to be done (i.e each graph) holds graph and active thread counts.
    atomic_int n_barrier;
    atomic_int n_barrier_passed;
    atomic_int current_chunk; // currently processing chunk during Mat_Mul, shared between all the threads.

    // these are atomic as an annotation for thread-sanitizer
    atomic_bool stop;         // Used for stopping the threadpool altogether
    atomic_bool pause;        // Used for pausing the threadpool or individual threads
    atomic_int  abort;        // Used for aborting processing of a graph

    struct ggml_compute_state * workers;   // per thread state
    int          n_threads;   // Number of threads in the pool
    int32_t      prio;        // Scheduling priority
    uint32_t     poll;        // Polling level (0 - no polling)

    enum ggml_status ec;
};

extern "C" void ggml_barrier(struct ggml_threadpool * tp) {
    int n_threads = atomic_load_explicit(&tp->n_graph, memory_order_relaxed) & GGML_THREADPOOL_N_THREADS_MASK;
    if (n_threads == 1) {
        return;
    }

    int n_passed = atomic_load_explicit(&tp->n_barrier_passed, memory_order_relaxed);

    // enter barrier (full seq-cst fence)
    int n_barrier = atomic_fetch_add_explicit(&tp->n_barrier, 1, memory_order_seq_cst);

    if (n_barrier == (n_threads - 1)) {
        // last thread
        atomic_store_explicit(&tp->n_barrier, 0, memory_order_relaxed);

        // exit barrier (full seq-cst fence)
        atomic_fetch_add_explicit(&tp->n_barrier_passed, 1, memory_order_seq_cst);
        return;
    }

    // wait for other threads
    while (atomic_load_explicit(&tp->n_barrier_passed, memory_order_relaxed) == n_passed) {
        ggml_thread_cpu_relax();
    }

    // exit barrier (full seq-cst fence)
    atomic_thread_fence(memory_order_seq_cst);
}
