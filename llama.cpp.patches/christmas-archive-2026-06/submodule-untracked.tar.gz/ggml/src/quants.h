// Stub header that redirects to llama.cpp/ggml/src/ggml-cpu/quants.h
#pragma once
#include "llama.cpp/ggml/src/ggml-cpu/quants.h"
