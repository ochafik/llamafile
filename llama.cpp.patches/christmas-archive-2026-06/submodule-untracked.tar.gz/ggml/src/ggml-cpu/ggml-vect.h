// [llamafile] Stub header that redirects to llamafile's ggml-vector.h
#pragma once
#include "llamafile/ggml-vector.h"
